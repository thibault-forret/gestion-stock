<?php

namespace Barryvdh\Debugbar\Twig\Extension;

use DebugBar\Bridge\Twig\DumpTwigExtension;

/**
 * Dump variables using the DataFormatter
 */
class Dump extends DumpTwigExtension
{
}
